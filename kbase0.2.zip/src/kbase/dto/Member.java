package kbase.dto;

public class Member {
	private String ID;
	private String PASSWORD;
	private String MBER_NM;
	private String REGIST_DT;
	private String REGISTER;

	public String getID() {
		return ID;
	}
	public void setID(String ID) {
		this.ID = ID;
	}
	public String getPASSWORD() {
		return PASSWORD;
	}
	public void setPASSWORD(String PASSWORD) {
		this.PASSWORD = PASSWORD;
	}
	public String getMBER_NM() {
		return MBER_NM;
	}
	public void setMBER_NM(String MBER_NM) {
		this.MBER_NM = MBER_NM;
	}
	public String getREGIST_DT() {
		return REGIST_DT;
	}
	public void setREGIST_DT(String REGIST_DT) {
		this.REGIST_DT = REGIST_DT;
	}
	public String getREGISTER() {
		return REGISTER;
	}
	public void setREGISTER(String REGISTER) {
		this.REGISTER = REGISTER;
	}

	
}
