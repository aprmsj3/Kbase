package kbase.dao;

import java.util.List;

import kbase.dto.Member;

public interface MemberMapper {
	//전체 회원의 데이터를 가져온다.
	public List<Member> selectAllMembers();
	
	//1개의 행의 데이터를 가져온다.
	public Member selectMember(String id);
	
	//회원 등록
	public void insertMember(Member member);
	
	//회원 수정
	public void updateMember(Member member);
	
	//회원 삭제
	public void deleteMameber(Member member);
}
