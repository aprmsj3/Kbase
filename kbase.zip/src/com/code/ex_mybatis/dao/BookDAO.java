package com.code.ex_mybatis.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.code.ex_mybatis.model.Book;

public class BookDAO {

	private SqlSessionFactory sqlSessionFactory = null; //세션 팩토리 초기화
	
	public BookDAO(SqlSessionFactory sqlSessionFactory){
		this.sqlSessionFactory = sqlSessionFactory;
	}
	
	public List<Book> selectAll(){ //Book객체의 모든 값을 조회한다.
		List<Book> list = null;
		SqlSession session = sqlSessionFactory.openSession();
		
		try{
			list = session.selectList("Book.selectAll");
		}finally{
			session.close();
		}
		
		return list;
	}
	
	public Book selectById(int id) //Book객체의 ID값을 조회
	{
		Book book = null;
		
		SqlSession session = sqlSessionFactory.openSession();
		
		try{
			book = session.selectOne("Book.selectById", id);
		} finally {
			session.close();
		}
		
		return book;
	}
	
	public int insert(Book book){ //Book 등록
		int id = -1;
		SqlSession session = sqlSessionFactory.openSession();
		
		try{
			id = session.insert("Book.insert", book);
		} finally {
			session.commit();
			session.close();
		}
		
		return id;
	}
	
	public void update(Book book){ //Book 수정
		SqlSession session = sqlSessionFactory.openSession();
		
		try{
			session.update("Book.update", book);
		} finally {
			session.commit();
			session.close();
		}
	}
	
	public void delete(int id){ //Book 삭제
		SqlSession session = sqlSessionFactory.openSession();
		
		try{
			session.delete("Book.delete", id);
		} finally {
			session.commit();
			session.close();
		}
	}
}
