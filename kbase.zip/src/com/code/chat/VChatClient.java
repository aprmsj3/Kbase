package com.code.chat;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class VChatClient implements Runnable, ActionListener{
	
	Frame f = null; //창 제목
	
	TextArea ta = null; //채팅창 영역
	TextField idField = null; //아이디 박스
	TextField messageField = null; //메시지 박스
	Button connectBtn = null; //연결 박스
	Panel p = null;
	
	Socket socket = null;
	
	DataOutputStream dos = null;
	DataInputStream dis = null;
	
	Thread t = null;
	
	public VChatClient()
	{
		f = new Frame("VChatClient");
		f.addWindowListener(
			new WindowAdapter()
			{
				public void windowClosing(WindowEvent we)
				{
					disConnect(); //클라이트쪽 연결 종료
					System.exit(0);
				}
			}
		);
		
		ta = new TextArea(); //텍스트 영역 인스턴스 변수 선언(텍스트 영역 설정)
		ta.setEditable(false); //텍스트 영역 내용 수정
		ta.setBackground(Color.WHITE); //텍스트영역 배경색 조정
		
		f.add(ta, BorderLayout.CENTER); //frame 레이아웃 배치 조정
		
		idField = new TextField(5); //텍스트 필드 길이
		messageField = new TextField(25);
		messageField.addActionListener(this);
		connectBtn = new Button("Connect"); //접속 버튼
		connectBtn.addActionListener(this);
		
		p = new Panel(); //패널 창 설정
		p.add(new Label("ID", Label.CENTER));
		p.add(idField);
		p.add(new Label("Message", Label.CENTER));
		p.add(messageField);
		p.add(connectBtn);
		
		f.add(p, BorderLayout.SOUTH);
		
		f.setSize(500, 400);
		Dimension d = f.getToolkit().getScreenSize();
		f.setLocation( (d.width - f.getWidth()) / 2, (d.height - f.getHeight())/2);
		f.setVisible(true);
	}
	
	@Override
	public void run() {
		try{
			while(true)
			{
				ta.append(dis.readUTF());
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	

	@Override
	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource() == connectBtn)
		{
			try
			{
				socket = new Socket("127.0.0.1", 7777); //주소, ip, port 정보 
				
				dos = new DataOutputStream(socket.getOutputStream());
				dis = new DataInputStream(socket.getInputStream());
				
				t = new Thread(this);
				t.start();
				
				dos.writeUTF(idField.getText());
				
				idField.setEditable(false);
				idField.setBackground(Color.GRAY);
				connectBtn.setEnabled(false);
			}catch(Exception e){
				System.out.println(e);
			}
		}else if(ae.getSource() == messageField)
		{
			try
			{
				dos.writeUTF(idField.getText() + "/" + messageField.getText());
				messageField.setText("");
			}catch(IOException ie)
			{
				System.out.println(ie);
			}
		}
	}
	
	public void disConnect()
	{
		try
		{
			socket.close();
			dis.close();
			dos.close();
			socket = null;
			dis = null;
			dos = null;
			t = null;
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}

	public static void main(String[] args)
	{
		VChatClient client = new VChatClient();
	}

}
