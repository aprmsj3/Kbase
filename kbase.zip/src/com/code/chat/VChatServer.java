package com.code.chat;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.TextArea;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class VChatServer {
	Frame f = null;
	TextArea ta = null;
	
	ServerSocket serverSocket = null;
	Socket socket = null;
	
	VChatServerThread serverThread = null;
	
	public VChatServer()
	{
		f = new Frame("VChatServer");
		ta = new TextArea();
		ta.setEditable(false);
		ta.setBackground(Color.WHITE);
		
		f.addWindowListener(
			new WindowAdapter(){
				public void windowClosing(WindowEvent we){
					System.exit(0);
				}
			}
		);
		
		f.add(ta);
		f.setSize(500, 400);
		Dimension d = f.getToolkit().getScreenSize();
		f.setLocation( (d.width - f.getWidth())/2, (d.height - f.getHeight())/2);
		f.setResizable(false);
		f.setVisible(true);
	}
	
	public void startServer()
	{
		try{
			serverSocket = new ServerSocket(7777);
			
			while(true)
			{
				socket = serverSocket.accept();
				serverThread = new VChatServerThread(socket, ta);
				serverThread.start();
			}
		}
		catch(IOException ie)
		{
			System.out.println(ie);
		}
	}
	
	public static void main(String[] args)
	{
		VChatServer server = new VChatServer();
		server.startServer();
	}
}
