package com.code.chat;

import java.awt.TextArea;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Vector;

public class VChatServerThread extends Thread 
{
	public static Vector clineList = new Vector(1, 1);
	Socket socket = null;
	TextArea ta = null;
	
	DataOutputStream dos = null;
	DataInputStream dis = null;
	
	String userName = null;
	
	public VChatServerThread(Socket socket, TextArea ta)
	{
		this.socket = socket;
		this.ta = ta;
	}
	
	public void run()
	{
		try
		{
			dos = new DataOutputStream(socket.getOutputStream());
			dis = new DataInputStream(socket.getInputStream());
			clineList.addElement(this);
			
			userName = dis.readUTF();
			ta.append("[" + userName +"]님이 접속하셨습니다.\n");
			messageCompare("LOGIN/" + userName);
			
			while(true)
			{
				messageCompare(dis.readUTF());
			}
		}
		catch(IOException ie)
		{
			//접속해제 처리
			ta.append("[" + userName + "]님이 접속을 해제 하였습니다.\n");
			messageCompare("LOGOUT/" + userName);
			disConnect();
		}
	}

	private void messageCompare(String message) {
		StringTokenizer st = new StringTokenizer(message, "/");
		String state = st.nextToken();
		String recvMessage = st.nextToken();
		
		if(state.equals("LOGIN"))
		{
			sendMessage("[" + userName + "]님이 접속하셨습니다.\n");
		}
		else if(state.equals("LOGOUT"))
		{
			sendMessage("[" + userName + "]님이 접속을 해제 하셨습니다.\n");
		}
		else
		{
			sendMessage("[" + state + "]" + recvMessage + "\n"); //state는 대화명으로 출력된다.
		}
	}
	
	private void sendMessage(String message) {
		synchronized (clineList) {
			try
			{
				Enumeration e = clineList.elements();
				
				while(e.hasMoreElements())
				{
					VChatServerThread temp = (VChatServerThread)e.nextElement();
					
					temp.dos.writeUTF(message);
				}
			}catch(Exception e)
			{
				System.out.println(e);
			}
		}
	}

	private void disConnect()
	{
		try
		{
			clineList.removeElement(this);
			dis.close();
			dos.close();
			socket.close();
			dis = null;
			dos = null;
			socket = null;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
