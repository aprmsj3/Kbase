package com.kbase.mybatis_2016_10_11;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

public class SqlSessionManager
{
	SqlSession sqlSession = null; //sqlSession 초기화
	
	public SqlSessionManager(SqlSession sqlSession)
	{
		this.sqlSession = sqlSession;
	}
	
	//전체 검색
	public List selectList(String sqlId)
	{
		return sqlSession.selectList(sqlId, "");
	}
	
	public List selectList(String sqlId, Map map)
	{
		return sqlSession.selectList(sqlId, map);
	}
	
	//단일 검색
	public Object selectOne(String sqlId)
	{
		return sqlSession.selectOne(sqlId);
	}
	
	public Object selectOne(String sqlId, Map map)
	{
		return sqlSession.selectOne(sqlId, map);
	}
	
	//등록
	public Object insert(String sqlId, Map map)
	{
		return sqlSession.insert(sqlId, map);
	}
	
	//수정
	public Object update(String sqlId, Map map)
	{
		return sqlSession.update(sqlId, map);
	}
	
	//삭제
	public Object delete(String sqlId, Map map)
	{
		return sqlSession.delete(sqlId, map);
	}
}
