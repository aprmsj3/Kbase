package com.kbase.mybatis_2016_10_11;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServlet;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class SqlSessionConfig extends HttpServlet {

	//session 등록
	private static SqlSessionFactory sqlSessionFactory;
	
	public void init()
	{
		try
		{
			InputStream inputStream = Resources.getResourceAsStream("com/kbase/db/mybatis/mybatis-config.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public static SqlSessionFactory getSqlSessionFactory()
	{
		return sqlSessionFactory;
	}
	
	public static void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory)
	{
		SqlSessionConfig.sqlSessionFactory = sqlSessionFactory;
	}
}
