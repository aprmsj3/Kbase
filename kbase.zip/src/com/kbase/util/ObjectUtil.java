package com.kbase.util;

import java.util.HashMap;
import java.util.Map;

public class ObjectUtil {
}
