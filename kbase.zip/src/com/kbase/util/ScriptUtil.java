package com.kbase.util;

public class ScriptUtil 
{
	//경고 메세지를 보여주는 자바스크립트 문자열을 생성
	public static String alert(String msg)
	{
		return alert(msg, null);
	}

	// 경고창과 이전으로 이동하는 문자열을 생성
	public static String alert(String msg, String history)
	{
		//StringBuffer는 문자열을 추가하거나 변경 할 때 주로 사용하는 자료형이다.
		StringBuffer ah = new StringBuffer("<script type=\"text/javascript\">");
		
		if(msg != null)
		{
			ah.append("alert(\"" + msg + "\");");
			ah.append("</script>");
		}
		
		if(history != null)
		{
			ah.append("history.go(" + history +")");
			ah.append("</script>");
		}
			
		return null;
	}
	
	//해당 url로 이동하는 스크립트 문자열을 생성
	public static String loactionHref(String location)
	{
		StringBuffer sc = new StringBuffer("<script type=\"text/javascript\">");
		
		if(location != null)
		{
			sc.append("loaction.href= \"" + location + "\"; ");
		}
		
		sc.append("</script>");
		
		return sc.toString();
	}
}
