package com.kbase.configure;

import org.apache.log4j.Logger;

public class Configure
{
	//logger를 보기위해선 org.apache.log4j jar파일이 필요하다.
	private static Logger logger = Logger.getLogger(Configure.class);
	
	//mybatis path 설정
	//public static String MYBATIS_CONFIG = "com/kbase/db/mybatis/mybatis-config.xml";
	
	//파일 구분자 -> file.separator = \ 
	public static String FILE_SEQ = System.getProperty("file.separator");
	
	//자바 버전
	public static String JAVA_VERSION = System.getProperty("java.version");
	
	//기본 Application 디렉토리
	public static String APP_DIR = null;
	
	//기본데이터 베이스
	public static String DS_NAME = "kbase";
	
	//Debug 모드 여부
	public static boolean IS_DEBUG = true;
	
	//서버 언어셋
	public static String SERVER_LANG = "UTF-8";
	
	//클라이언트 언어셋
	public static String CLIENT_LANG = "UTF-8";
	
/*	public static void printStatus()
	{
		logger.info("Java version :" + Configure.JAVA_VERSION);
		logger.info("FILE_SEQ :" + Configure.FILE_SEQ);
		logger.info("Application path(프로젝트 경로) : " + Configure.APP_DIR);
		logger.info("Default DS Name :" + Configure.DS_NAME);
		logger.info("Is debug :" + Configure.IS_DEBUG);
	}*/
}
