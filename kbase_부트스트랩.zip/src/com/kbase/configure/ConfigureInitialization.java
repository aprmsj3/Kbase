package com.kbase.configure;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;

public class ConfigureInitialization extends HttpServlet
{
	private static Logger logger = Logger.getLogger(ConfigureInitialization.class);
	
	public void init() throws ServletException
	{
		try
		{
			//파일 절대경로
			Configure.APP_DIR = getServletContext().getRealPath(""); 
			
			logger.info("Java version :" + Configure.JAVA_VERSION);
			//logger.info("FILE_SEQ :" + Configure.FILE_SEQ);
			logger.info("Application path(프로젝트 경로) : " + Configure.APP_DIR);
			logger.info("Default DS Name :" + Configure.DS_NAME);
			logger.info("Is debug :" + Configure.IS_DEBUG);
			logger.info("Configure Load Ok!");
		}
		catch(Exception e)
		{
			logger.error("Configure Load Error!", e);
		}
	}
}
