package com.kbase.util;

import java.util.HashMap;
import java.util.Map;

public class Kmap extends HashMap{

		/*
		 * 여기서 super는 상속 받은 상위 객체의 생성자를 호출한다.
		 */
	
		public Kmap()
		{
			super(); //HashMap의 생성자를 호출한다.
		}
		
		
		/*
		 * initialCapacity : 지정된 초기 사이즈
		 * buket : Map이 서랍장이면 buket은 각각의 서랍이라고 생각하면 된다.
		  - 기본적으로 용량은 buket의 수이며 기본 초기용량 수는 16이다.
		 * loadFactor : 총 수용가능한 element의수 / 용량으로 정의 된다.
		  - 메소드가 실행 될 때 수용가능 용량을 계산해서 이 값(loadFactor * 용량)을 넘어서면 용량을 2배로 늘린다.
		  - 여기서 유의할점은 load factor가 너무 크면(즉, 한 bucket에 많은 element를 넣게 되면) 메모리 절약은 할 수 있으나, 검색이 힘들어 진다.
			반대로 너무 작으면(bucket의 수가 너무 많으면), 검색은 빠르겠지만, 메모리 상의 낭비가 일어나게 된다.
			가장 최적의 값은 일반적으로 0.75라고 한다.
		 */ 
		public Kmap(int initialCapacity, float loadFactor)
		{
			super(initialCapacity, loadFactor);
		}
		
		
		/*
		 	생성자 초기화 시 초기 용량이 16이 아닌 다른 값을 쓸 수 있다.
		 */
		public Kmap(int initialCapacity)
		{
			super(initialCapacity);
		}
		
		/* Map map을 호출 */
		public Kmap(Map map)
		{
			super(map);
		}
		
		public String toString()
		{
			return super.toString();
		}
		
		/*
		 * 반환 할 object가 null이면 ""을 반환한다. 
		 */
		public String getString(Object key)
		{
			return getString(key, "");
		}

		public String getString(Object key, String value)
		{
			Object obj = this.get(key);
			if(obj != null)
			{
				return obj.toString();
			}
			else
			{
				return value;
			}
		}

		/*
		 * key 값이 없을 경우 0을 반환 
		 */
		
		public int getInt(Object key)
		{
			return getInt(key, 0);
		}
		
		public int getInt(Object key, int value)
		{
			int returnValue = 0;
			
			String obj = this.getString(key, null);
			
			if(obj == null)
			{
				returnValue = value;
			}
			else
			{
				try
				{
					returnValue= Integer.parseInt(obj);
				}
				catch(NumberFormatException e)
				{
					returnValue = value;
				}
			}
			
			return returnValue;
		}
}
