package com.kbase.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.kbase.mybatis.SqlSessionManager;

public class Util {
	
	public static SqlSessionFactory sqlSessionFactory = SqlSessionManager.getSqlSession();
	public static SqlSession sqlSession = sqlSessionFactory.openSession();

	public static String MapKeyData(String key, HashMap data)
	{
		
		Iterator ir = data.keySet().iterator(); //data맵의 모든 key값을 ir객체에 담는다.

		while(ir.hasNext())
		{
			String allkey = (String)ir.next();//하나씩 key 값을 가져온다.
			
			if(key.equals(allkey)) //값을 비교
			{
				String value = (String)data.get(key);
				
				return value;
			}
		}
		return key;
	}
}
