package com.code.ex_mybatis.model;

import java.util.List;

import com.code.ex_mybatis.dao.BookDAO;
import com.code.ex_mybatis.mybatis.MyBatisConnectionFactory;

public class Main {
	public static void main(String[] args){
		
		BookDAO bookDAO = new BookDAO(MyBatisConnectionFactory.getSqlSessionFactory());
		
		Book book = new Book();
		
		//create
		System.out.println("==INSERT==");
		
		book.setId(1);
		book.setName("홍길동전");
		bookDAO.insert(book);
		
		book.setId(2);
		book.setName("레미제라블");
		bookDAO.insert(book);
		
		//Read
		List<Book> bookList = bookDAO.selectAll();
		
		for(Book bookInfo: bookList){
			System.out.println("Book ID: "+bookInfo.getId());
			System.out.println("Book NAME: "+bookInfo.getName());
		}
		
		//Update
		System.out.println("");
		System.out.println("==UPDATE==");
		
		book.setId(2);
		book.setName("해저 2만리");
		bookDAO.update(book);
		
		//Read
		book = bookDAO.selectById(2);
		System.out.println("BOOK ID:" + book.getId());
		System.out.println("BOOK NAME:" + book.getName());
		
		//Delete
		System.out.println("");
		System.out.println("==DELETE==");
		
		bookDAO.delete(2);
		
		//Read
		bookList.clear();
		bookList = bookDAO.selectAll();
		for(Book bookInfo : bookList){
			System.out.println("BOOK ID: "+ bookInfo.getId());
			System.out.println("BOOK NAME: "+ bookInfo.getName());
		}
	}
}
