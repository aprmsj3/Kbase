package com.code.ex_mybatis_object.dao;

import java.util.List;

import com.code.ex_mybatis_object.dto.User;


public interface UserMapper {
	public List<User> selectAllUsers();
	public User selectUser(String username);
	public void insertUser(User user);
	public void updateUser(User user);
	public void deleteUser(String username);
}
