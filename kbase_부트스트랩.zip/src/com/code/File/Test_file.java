package com.code.File;

import java.io.File;

public class Test_file {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File("/test/test");
	}

}
