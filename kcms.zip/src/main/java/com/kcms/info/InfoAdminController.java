package com.kcms.info;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class InfoAdminController {
	private static final Logger logger = LoggerFactory.getLogger(InfoAdminController.class);
	
	/**
	 * @Comment : DB Convert 참고
	 * @method  : infoDB
	 * @class   : InfoAdminController
	 * @param map
	 * @param reqset
	 * @param response
	 * @return ModelAndView
	 */
	@RequestMapping(value="/admin/info/adminInfoDB.do", method={RequestMethod.POST, RequestMethod.GET})
	public ModelAndView infoDB(HashMap map, HttpServletRequest request, HttpServletResponse response)
	{
		ModelAndView mv = new ModelAndView("admin.info.adminInfoDB");
		
		return mv;
	}
	
	/**
	 * @Comment : oracle 함수 참고
	 * @method  : oracleV
	 * @class   : InfoAdminController
	 * @param map
	 * @param reqset
	 * @param response
	 * @return ModelAndView
	 */
	@RequestMapping(value="/admin/info/popup/oracleV.do", method={RequestMethod.POST, RequestMethod.GET})
	public ModelAndView oracleV(HashMap map, HttpServletRequest request, HttpServletResponse response)
	{
		ModelAndView mv = new ModelAndView("admin.info.popup.oracleV");
		
		return mv;
	}
}
