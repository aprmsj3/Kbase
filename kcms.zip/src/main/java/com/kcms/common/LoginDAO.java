package com.kcms.common;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Repository;

@Repository("loginDAO")
public class LoginDAO extends AbstractDAO {

	public List selectMember(HashMap map, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return selectList("member.T90_MEMBER_select_01", map);
	}

}
