package com.kcms.common;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface LoginService {

	/* 회원리스트 가져오기*/
	List selectMember(HashMap map, HttpServletRequest request, HttpServletResponse response) throws Exception;

}
