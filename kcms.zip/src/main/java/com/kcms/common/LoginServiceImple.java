package com.kcms.common;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginServiceImple implements LoginService {
	
	@Resource(name="loginDAO")
	private LoginDAO loginDAO;

	/* 회원리스트 가져오기*/
	public List selectMember(HashMap map, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return loginDAO.selectMember(map, request, response);
	}

}
