package com.kcms.common;

import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Resource(name="loginService")
	private LoginService loginService;
	
	/**
	 * @Comment : 로그인 페이지
	 * @method  : login
	 * @class   : LoginController
	 * @param map
	 * @param reqset
	 * @param response
	 * @return ModelAndView
	 */
	@RequestMapping(value="/index.do", method = {RequestMethod.POST, RequestMethod.GET})
	public ModelAndView login(HashMap map, HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		ModelAndView mv = new ModelAndView("/login/login");
		
		return mv;
	}
}
