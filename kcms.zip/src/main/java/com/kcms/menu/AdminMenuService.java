package com.kcms.menu;

public interface AdminMenuService {

}
