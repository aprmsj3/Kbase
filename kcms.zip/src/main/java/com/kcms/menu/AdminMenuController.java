package com.kcms.menu;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AdminMenuController {

	private static final Logger logger = LoggerFactory.getLogger(AdminMenuController.class);
	
	/**
	 * @Comment : 관리자 메뉴 리스트
	 * @method  : adminMenuL
	 * @class   : AdminMenuController
	 * @param map
	 * @param reqset
	 * @param response
	 * @return ModelAndView
	 */
	@RequestMapping(value="/menu/adminMenuL.do", method = {RequestMethod.POST, RequestMethod.GET})
	public ModelAndView adminMenuL(HashMap map, HttpServletRequest request, HttpServletResponse response)
	{
		ModelAndView mv = new ModelAndView("admin.menu.list");
		
		return mv;
	}
}
