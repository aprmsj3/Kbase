package com.kcms.menu;

public class AdminMenuServiceImple {

}
