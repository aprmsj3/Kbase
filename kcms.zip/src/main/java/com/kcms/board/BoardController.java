package com.kcms.board;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BoardController {

	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Resource(name="boardService")
	private BoardService boardService;
	
	/**
	 * @Comment : 게시판(테이블) 리스트
	 * @method  : bbsTL
	 * @class   : BbsController
	 * @param : map
	 * @param : reqset
	 * @param : response
	 * @return : ModelAndView
	 */
	@RequestMapping(value = "/admin/boardT/boardL.do", method = {RequestMethod.POST, RequestMethod.GET})
	public ModelAndView bbsTL(HashMap map, HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		ModelAndView mv = new ModelAndView("admin.boardT.list");
		
		List list = boardService.selectBoardList(map, request, response);
		mv.addObject("list", list);
		
		return mv;
	}
	
	/**
	 * @Comment : 게시판(그리드) 리스트
	 * @method  : bbsGL
	 * @class   : BbsController
	 * @param : map
	 * @param : reqset
	 * @param : response
	 * @return : ModelAndView
	 */
	@RequestMapping(value = "/admin/boardG/boardL.do", method = {RequestMethod.POST, RequestMethod.GET})
	public ModelAndView bbsGL(HashMap<String, Object> map, HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		ModelAndView mv = new ModelAndView("admin.boardG.list");
		
		return mv;
	}
	
	/**
	 * @Comment : 게시판 목록 그리드
	 * @method  : bbsAG
	 * @class   : BbsController
	 * @param : map
	 * @param : reqset
	 * @param : response
	 * @return : ModelAndView
	 */
	@RequestMapping(value = "/admin/boardG/boardAG.do", method = {RequestMethod.POST, RequestMethod.GET})
	public ModelAndView bbsAG(HashMap map, HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		ModelAndView mv = new ModelAndView("admin.boardG.list");
		mv.setViewName("jsonView");
		mv.addObject(boardService.selectBoardList(map, request, response));
		
		return mv;
	}
}
