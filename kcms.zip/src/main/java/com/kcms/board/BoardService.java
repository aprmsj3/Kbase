package com.kcms.board;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface BoardService {

	/* 게시판 리스트 */
	List selectBoardList(HashMap map, HttpServletRequest request, HttpServletResponse response) throws Exception;
}
