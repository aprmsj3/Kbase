package com.kcms.board;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.kcms.common.AbstractDAO;

@Repository("boardDAO")
public class BoardDAO extends AbstractDAO {

	public List selectBoardList(HashMap map) throws Exception{
		return selectList("board.T91_BBS_selectList_01", map);
	}
}
