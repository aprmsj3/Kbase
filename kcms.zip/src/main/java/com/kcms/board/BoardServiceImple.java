package com.kcms.board;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("boardService")
public class BoardServiceImple implements BoardService {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardServiceImple.class);
	
	@Resource(name="boardDAO")
	private BoardDAO boardDAO;

	public List selectBoardList(HashMap map, HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		return boardDAO.selectBoardList(map);
	}
}
