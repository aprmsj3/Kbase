﻿<?php include_once("../db/db_connect.php"); ?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="Content-Script-Type" content="text/javascript" />
		<meta http-equiv="Content-Style-Type" content="text/css" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

		<title>로그인 폼</title>
		<link rel="stylesheet" type="text/css" href="../css/login.css" />
		<link rel="stylesheet" type="text/css" href="../fontawesome-free-5.6.3/css/all.min.css" />

		<script type="text/javascript" src="<?php $_SERVER['DOCUMENT_ROOT']?>/js/jquery-3.3.1.js"></script>
		<script type="javascript" src="../fontawesome-free-5.6.3/js/all.min.js"></script>

		<style>
			.login_wrap{border:1px solid white; padding:30px; border-radius:20px; background-color:rgba( 0, 0, 0, 0.2 );}
			.login_wrap h1{height:23px;}

			.login_header_title{padding-bottom:20px; border-bottom:2px solid #fff; font-size:40px; font-weight:bold;}
			.login_input{vertical-align:sub; height:25px; border-radius:20px; padding-left:10px; border-style:none; margin-top:21px;}
			.login_btn{font-size:35px; background:transparent; cursor:pointer; border-radius:20px; color:#fff; border-style:none; margin-top:20px;}
			.login_border{height:1px; border-bottom:2px solid #fff; border-spacing:10px;}
		</style>

		<script>
			function loginSubmit()
			{
				if("" == $("#id").val())
				{
					alert("아이디를 입력해 주세요.");
					$("#id").focus();
					return false;
				}

				if("" == $("#password").val())
				{
					alert("비밀번호를 입력해 주세요.");
					$("#password").focus();
					return false;
				}
			}
		</script>
	</head>

	<body>
		<div id="wrap">
			<form id="loginForm" name="loginForm" method="POST" onsubmit="return loginSubmit();">
				<div class="login_wrap">
					<div class="login_header_title">Login</div>
					<table>
						<colgroup>
							<col width="30%"; />
							<col width="70%"; />
						</colgroup>
						<tr>
							<th><h1><i class="fas fa-user-circle"></i></h1></th> <!-- user -->
							<td><input class="login_input" type="text" id="id" name="id" /></td>
						</tr>
						<tr>
							<td colspan="2"><div class="login_border"></div></td>
						</tr>
						<tr>
							<th><h1><i class="fas fa-lock"></i></h1></th> <!-- password -->
							<td><input class="login_input" type="password" id="password" name="password" /></td>
						</tr>
						<tr>
							<td colspan="2"><div class="login_border"></div></td>
						</tr>
					</table>
					 <button type="submit" class="login_btn"><i class="fas fa-power-off"></i></button>
				</div>		
			</form>
		</div>
	</body>

</html>