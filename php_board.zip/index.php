﻿<?php include_once("path_info.php"); ?>

<html>
	<body>
		<h1>Test</h1>
	</body>
</html>

