﻿<?php include_once("/config.php"); ?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>메인 페이지</title>

		<style>
			
		</style>
	</head>
	<body>
		<a href="<?php $web_path?>/grid/list.php">그리드 게시판으로 이동</a> <br />
		<a href="<?php $web_path?>/login/login.php" target="_blank">로그인 페이지로 이동</a> <br />


		<a href="<?php $web_path?>/info/board_manual.php">게시판 DB 정리</a> <br />
		<a href="<?php $web_path?>/list.php?pn=1">게시판 리스트로 이동</a> <br />
		<a href="<?php $web_path?>/gallery/list.php">이미지 게시판 리스트로 이동</a><br />

		<h1>소스 예제</h1>
		<a href="<?php $web_path?>/example/ex_file/index.php">파일업로드 예제</a> <br />
		<a href="<?php $web_path?>/example/responsive/loginForm1.html" target="_blank">로그인폼1 예제</a> <br />
	</body>
</html>

