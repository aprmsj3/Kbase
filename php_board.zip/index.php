﻿<?php include_once("/info/config.php"); ?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>메인 페이지</title>

		<style>
			
		</style>
	</head>
	<body>
		<a href="<?php $web_path?>/info/board_manual.php">게시판 DB 정리</a> <br />
		<a href="<?php $web_path?>/list.php?pn=1">게시판 리스트로 이동</a> <br />
		<a href="<?php $web_path?>/gallery/list.php">이미지 게시판 리스트로 이동</a><br />

		<a href="<?php $web_path?>/example/ex_file/index.php">파일업로드 예제</a> <br />
	</body>
</html>

