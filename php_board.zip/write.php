﻿<?php include_once("/config.php"); ?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>게시판 등록 페이지</title>

		<style>
			table{border:1px solid black; border-collapse:collapse; width:600px;}
			table th, td{margin:0; padding:0px;}
			table caption{text-align:left;}
			table th{text-align:center; border:1px solid black; padding:5px;}
			table td{text-align:left; border:1px solid black; color:#E1E3EB;  padding:5px;}
			.tCenter{text-align:center;}
			.full-width{width:100%;}
			.p-width99{width:99%;}

			.button_area{width:600px; margin-top:5px; text-align:right;}
		</style>

		<script type="text/javascript">
		
			function writeFormCheck()
			{
				if("" == $("#title").val())
				{
					alert("제목을 입력해 주십시오.");
					$("#title").focus();
					return false;
				}

				if("" == $("#content").val())
				{
					alert("내용을 입력해 주십시오.");
					$("#content").focus();
					return false;
				}
			}
		</script>
	</head>
	<body>
		<h1>글 작성</h1>
		<form action="<?php $web_path?>/insert.php" name="writeForm" method="POST" onsubmit="return writeFormCheck();">
			<table>
				<tr>
					<th>제목</th>
					<td><input type="text" class="full-width" id="title" name="title" /></td>
				</tr>
				<tr>
					<th>내용</th>
					<td>
						<textarea class="p-width99" rows="30" id="content" name="content" ></textarea>
					</td>
				</tr>
			</table>
			<div class="button_area">
				<button type="submit">글 작성</button>
				<button type="button" onclick="goHome();">작성 취소</button>
			</div>
		</form>
	</body>
</html>

