﻿<?php include_once("../config.php"); ?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>이미지 게시판 등록 페이지</title>

		<style>
			table{border:1px solid black; border-collapse:collapse; width:700px;}
			table th, td{margin:0; padding:0px;}
			table caption{text-align:left;}
			table th{text-align:center; border:1px solid black; padding:5px;}
			table td{text-align:left; border:1px solid black; color:black;  padding:5px;}

			.button_area{width:700px; margin-top:5px; text-align:right;}
		</style>

		<script type="text/javascript">
		
			function writeFormCheck()
			{
				if("" == $("#title").val())
				{
					alert("제목을 입력해 주십시오.");
					$("#title").focus();
					return false;
				}

				if("" == $("#content").val())
				{
					alert("내용을 입력해 주십시오.");
					$("#content").focus();
					return false;
				}


				if("" == $("#uploadFile").val())
				{
					alert("이미지를 등록해 주십시오.");
					$("#uploadFile").focus();
					return false;
				}

				/* file image 확장자 체크 필요.. */
				var obj = $("#uploadFile").val();

				// 선택한 파일의 경로를 분리하여 확장자를 구함
				var pathPoint = obj.lastIndexOf('.');
				var imgSplit = obj.substring(pathPoint+1, obj.length);
				var imgType = imgSplit.toLowerCase();

				//이미지 파일 체크
				if(imgType == "jpg" || imgType == "jpeg" || imgType == "png" || imgType == "gif" || imgType == "bmp")
				{
					return true;
				}else{
					alert("jpg, jpeg, png, gif, bmp로 된 이미지 파일만 업로드가 가능합니다.");
					return false;
				}
			}

			$("#uploadFile").change(function(){
				previewImage(this);
			});

			function backGallery()
			{
				location.href = "<?php $web_path ?>/gallery/list.php";
			}

			function previewImage(imgObj)
			{
				if(imgObj.files && imgObj.files[0])
				{
					var reader = new FileReader();

					reader.onload = function (e) {
						$("#select_img").attr('src', e.target.result);
					}

					reader.readAsDataURL(imgObj.files[0]);
				}
			}
		</script>
	</head>
	<body>
		<h1>글 작성</h1>
		<form action="<?php $web_path?>/gallery/insert.php" name="writeForm" method="POST" onsubmit="return writeFormCheck(this);" enctype="multipart/form-data">
			<table>
				<tr>
					<th>제목</th>
					<td><input type="text" class="full-width" id="title" name="title" /></td>
				</tr>
				<tr>
					<th>내용</th>
					<td>
						<textarea class="p-width99" rows="30" id="content" name="content" ></textarea>
					</td>
				</tr>
				<tr>
					<th>첨부파일</th>
					<td>
						<input type="file" id="uploadFile" name="uploadFile" onchange="previewImage(this);" style="color:black; margin-bottom:5px;" /> <br />
						<div>[미리보기 화면]</div><img id="select_img" width=600px; height=400px; />
					</td>
				</tr>
			</table>
			<div class="button_area">
				<button type="submit">글 작성</button>
				<button type="button" onclick="backGallery();">작성 취소</button>
			</div>
		</form>
	</body>
</html>

