﻿<?php include_once("../config.php"); ?>
<?php include_once("../db/db_connect.php"); ?>

<?php
	//파일 경로 선언

	$fileNo = uniqid();

	$name = $_FILES['uploadFile']['name']; //파일명
	$ext = array_pop(explode('.', $name)); //확장자
	$maskFileNm = $fileNo.".".$ext; //마스크파일명
	$size = $_FILES['uploadFile']['size']; //파일 이름

	$upload_dir = $_SERVER['DOCUMENT_ROOT']."/gallery/attach/";

	if($result = mysqli_query($conn, "SELECT * FROM B01_BOARD"))
	{
		$row_cnt = mysqli_num_rows($result);
	}

	//전송 시 POST방식으로 받기
	$title = addslashes($_POST["title"]);
	$content = addslashes($_POST["content"]);
	
	//등록 쿼리
	$insert_query = "INSERT INTO B01_BOARD (BOARD_NO,TITLE,CONTENT,WRITER,MODIFIER,REGIST_DT,UPDT_DT,BOARD_TYPE) VALUES ($row_cnt+1, '$title', '$content', '$user', null, now(), null, 'B')";
	$insert_result = mysqli_query($conn, $insert_query);

	//파일 등록 쿼리
	$file_insert_query = "INSERT INTO b02_file( FILE_NO ,BOARD_NO, FILE_NM, FILE_TYPE, FILE_PATH, MASK_FILE_NM, FILE_SIZE, DOWN_CNT, WRITER, MODIFIER ,REGIST_DT, UPDT_DT ) VALUES('$fileNo', $row_cnt+1, '$name', '$ext', '$upload_dir', '$maskFileNm', '$size', 0, '$user', null, now(), null)";
	$file_insert_result = mysqli_query($conn, $file_insert_query);

	if($insert_result === false && $file_insert_result == false)
	{
		echo mysqli_error($conn)."<br />";
	}else{
		move_uploaded_file($_FILES['uploadFile']['tmp_name'], $upload_dir."/".$fileNo.".".$ext);

		echo "<script>
				alert(\"등록 되었습니다.\");
				location.href = \"/gallery/list.php\";
			 </script>";
	}

	mysqli_close($conn);
?>