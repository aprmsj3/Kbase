﻿<?php include_once("../config.php"); ?>
<?php include_once("../db/db_connect.php"); ?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>이미지게시판 리스트 페이지</title>

		<style>

			.gallery_list{margin-top:10px; padding-top:30px; border-top: 1px solid #ccc;}

			div.gallery{border:1px solid #ccc;}
			div.gallery:hover{border:1px solid #777;}
			div.gallery img{width:100%; height:auto;}
			div.desc{padding:15px; text-align:center;}
			*{box-sizing:border-box;}
			.responsive{padding: 0 6px; float:left; width:24.99999%; margin-bottom:5px;}

			@media only screen and (max-width:700px)
			{
				.responsive{width:49.99999%; margin:6px 0;}
			}

			@media only screen and (max-width:500px)
			{
				.responsive{width:100%;}
			}

			.clearfix:after{content:""; display:table; clear:both;}
		</style>

		<script type="text/javascript">
			
			function hrefWrite()
			{
				location.href = "<?php $web_path?>/gallery/write.php";
			}
			
		</script>
	</head>
	<body>
		<a href="<?php $web_path?>/index.php">홈으로</a> <br />

		<h2>이미지게시판 리스트 - Responsive Image Gallery</h2>

		<div style="margin-left:6px;">
			<button type="button" onclick="hrefWrite()">등록</button>
		</div>

		<div class="gallery_list">
			<div class="responsive">
				<div class="gallery">
					<a href="#">
						<img src="img_5terre.jpg" alt="Cinque Terre" width="600" height="400" />
					</a>
					<div class="desc">1</div>
				</div>
			</div>

			<div class="responsive">
				<div class="gallery">
					<a href="#">
						<img src="img_forest.jpg" alt="Forest" width="600" height="400" />
					</a>
					<div class="desc">2</div>
				</div>
			</div>

			<div class="responsive">
				<div class="gallery">
					<a href="#">
						<img src="img_lights.jpg" alt="Northern Lights" width="600" height="400" />
					</a>
					<div class="desc">3</div>
				</div>
			</div>

			<div class="responsive">
				<div class="gallery">
					<a href="#">
						<img src="img_mountains.jpg" alt="Mountains" width="600" height="400" />
					</a>
					<div class="desc">4</div>
				</div>
			</div>
		</div>
	
		<div class="clearfix"></div>

	</body>
</html>
