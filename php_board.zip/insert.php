﻿<?php include_once("/config.php"); ?>
<?php include_once("/db/db_connect.php"); ?>

<?php
	
	//전송 시 POST방식으로 받기
	$title = addslashes($_POST["title"]);
	$content = addslashes($_POST["content"]);

	
	//등록 쿼리
	$insert_query = "INSERT INTO B01_BOARD (BOARD_NO,TITLE,CONTENT,WRITER,MODIFIER,REGIST_DT,UPDT_DT,BOARD_TYPE) VALUES ('".uniqid()."', '$title', '$content', '$user', null, now(), null,'A')";
	$insert_result = mysqli_query($conn, $insert_query);

	if($insert_result === false)
	{
		echo mysqli_error($conn)."<br />";
	}else{
		echo "<script>
				alert(\"등록 되었습니다.\");
				location.href = \"$web_path/list.php\";
			 </script>";
	}

	mysqli_close($conn);
?>