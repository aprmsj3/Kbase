﻿<?php include_once("/config.php"); ?>
<?php include_once("/db/db_connect.php"); ?>

<?php 
	$pn = $_GET['pn'];

	$select_query = "SELECT * FROM b01_board WHERE BOARD_NO=".$_GET['boardNo'];
	$result_set = mysqli_query($conn, $select_query);

	$row = mysqli_fetch_array($result_set);
?>

<script type="text/javascript">
	
	var boardNo = "<? echo $_GET['boardNo']; ?>";
	var pn = "<? echo $pn ?>";

	function hrefModifiedPage()
	{
		location.href = "<?php $web_path?>/modified.php?boardNo="+boardNo+"&pn="+pn;
	}

	function boardDelete()
	{
		if(confirm("게시판을 삭제 하시겠습니까?"))
		{
			$.ajax
			(
				{
					type : "POST",
					url : "<? $web_path?>/delete.php",
					data : {"boardNo" : boardNo},
					success : function (data)
					{
						alert("게시판이 삭제 되었습니다.");
						location.href = "<? $web_path?>/list.php";
					},
					error : function(xhr, status, error)
					{
						alert("삭제 중 오류가 발생했습니다.\n");
						return false;
					}
				}
			);
		}
	}
</script>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>게시판 상세 페이지</title>

		<style>
			table{border:1px solid black; border-collapse:collapse; width:600px;}
			table th, td{margin:0; padding:0px;}
			table caption{text-align:left;}
			table th{text-align:center; border:1px solid black; padding:5px;}
			table td{text-align:left; border:1px solid black; padding:5px;}
			.tCenter{text-align:center;}
			.full-width{width:100%;}
			.p-width99{width:99%;}

			.button_area{width:600px; margin-top:5px; text-align:right;}
		</style>

		<script type="text/javascript">
		
		</script>
	</head>
	<body>
		<h1>상세 페이지</h1>
			<table>
				<tr>
					<th>제목</th>
					<td><? echo $row['TITLE']; ?></td>
				</tr>
				<tr>
					<th>내용</th>
					<td>
						<textarea class="p-width99" rows="30" id="content" name="content" readonly="readonly" ><? echo $row['CONTENT']; ?></textarea>
					</td>
				</tr>
			</table>
			<div class="button_area">
				<button type="button" onclick="hrefModifiedPage();">글 수정</button>
				<button type="button" onclick="boardDelete();">글 삭제</button>
				<button type="button" onclick="goHome('<?echo $pn ?>');">이전으로</button>
			</div>
	</body>
</html>

<?php mysqli_close($conn); ?>