﻿<?php include_once("../db/db_connect.php"); ?>

<?php 
	$title = addslashes($_POST["title"]);
	$content = addslashes($_POST["content"]);

	//그리그 데이터 등록
	$insert_query = "insert into b01_board( BOARD_NO,TITLE,CONTENT,WRITER,MODIFIER,REGIST_DT,UPDT_DT,BOARD_CNT,BOARD_TYPE )
					 values( '".uniqid()."', '".$title."', '".$content."', 'user', null, now(), null, 0, 'C' )";
	$result = mysqli_query($conn, $insert_query);

	if($insert_result === false)
	{
		echo mysqli_error($conn)."<br />";
	}

	mysqli_close($conn);
?>