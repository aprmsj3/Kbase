﻿<?php include_once("../db/db_connect.php"); ?>

<?php

	$boardNo = $_POST['boardNo'];

	//삭제 쿼리
	$grid_delete_query = "DELETE FROM b01_board	WHERE BOARD_NO = '".$boardNo."'";

	$result = mysqli_query($conn, $grid_delete_query);

	if($result === false)
	{
		echo mysqli_error($conn)."<br />";
	}

	mysqli_close($conn);

?>