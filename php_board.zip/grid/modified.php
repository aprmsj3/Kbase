﻿<?php include_once("../db/db_connect.php"); ?>

<?php

	$select_one_query = "SELECT * FROM b01_board WHERE BOARD_NO='".$_GET['boardNo']."'";
	$result_set = mysqli_query($conn, $select_one_query);

	$row = mysqli_fetch_array($result_set);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">

		<style>
			table.dialogForm{border:1px solid black; border-collapse:collapse; width:100%;}
			table.dialogForm th, td{margin:0; padding:0px;}
			table.dialogForm caption{text-align:left;}
			table.dialogForm th{text-align:center; border:1px solid black; padding:5px;}
			table.dialogForm td{text-align:left; border:1px solid black; color:#E1E3EB;  padding:5px;}

			.dialog_button_area{width:100%; margin-top:5px; text-align:right;}
		</style>

		<script type="text/javascript">
			
			$(function()
			{
				$("#modifiedForm").ajaxForm({
					dataType : "html",
					beforeSend : function(){},
					success : function(data, status)
					{
						data.trim();
						alert("게시글을 수정하였습니다.");
						$("#grid_dialog").dialog("close");
						reloadGrid();
					},
					error : function(data, status)
					{
						alert("수정 중에 문제가 발생하였습니다.");
						return false;
					}
				});
			});	
			
			function gridDelete()
			{
				if(confirm("게시판을 삭제 하시겠습니까?"))
				{
					$.ajax({
						url : "<?php $_SERVER['DOCUMENT_ROOT'] ?>/grid/delete.php",
						data : {"boardNo" : $("#boardNo").val()},
						type : "POST",
						success : function(data)
						{
							alert("게시판이 삭제 되었습니다.");
							$("#grid_dialog").dialog("close");
							reloadGrid();
						},
						error : function(xhr, status, error)
						{
							alert("삭제 중 오류가 발생했습니다.");
							return false;
						}
					});
				}
			}

		</script>
	</head>
	<body>
		<form action="<?php $_SERVER['DOCUMENT_ROOT'] ?>/grid/update.php" method="POST" id="modifiedForm" name="modifiedForm">
			<input type="hidden" id="boardNo" name="boardNo" value="<?php echo $row['BOARD_NO'] ?>" />
			<table class="dialogForm">
				<tr>
					<th>제목</th>
					<td><input type="text" class="full-width" id="title" name="title" value="<?php echo $row['TITLE'] ?>" /></td>
				</tr>
				<tr>
					<th>내용</th>
					<td>
						<textarea class="p-width99" rows="20" id="content" name="content"><?php echo $row['CONTENT'] ?></textarea>
					</td>
				</tr>
			</table>
			<div class="dialog_button_area">
				<button type="submit">수정</button>
				<button type="button" onclick="gridDelete();">삭제</button>
				<button type="button" onclick="closeGridForm();">닫기</button>
			</div>
		<form>
	</body>
</html>
