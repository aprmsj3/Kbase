<?php

	header("Content-Type:application/json; charset=utf-8");

	$conn = mysqli_connect('localhost', 'root', 'autoset', 'board');


	if($conn->connect_errno)
	{
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}

	$limit=$_POST['rows']; //���� �� ���� ��
	$page=$_POST['page']; //1page
	$sidx=$_POST['sidx']; //Ű��
	$sord=$_POST['sord']; //���İ�

	$count_sql = "SELECT COUNT(0) FROM b01_board WHERE BOARD_TYPE = 'C'";
	$count_query = mysqli_query($conn, $count_sql);
	$row_count = mysqli_fetch_row($count_query);
	$count = $row_count[0];

	$total_pages = ceil($count/$limit);
	if($page > $total_pages){
		$page = $total_pages;
	}

	$start = $limit*$page - $limit;
	$end = $page * $limit;

	$search_condition = 'LIMIT ' .$start.','.$end;

	$sql = "SELECT
				@rownum:= @rownum+1 AS RNUM,
				BOARD_NO,
				TITLE,
				CONTENT,
				WRITER,
				MODIFIER,
				REGIST_DT,
				DATE_FORMAT(REGIST_DT, '%Y-%m-%d') AS YMD,
				UPDT_DT,
				ifnull(BOARD_CNT, 0) as BOARD_CNT
			FROM
				b01_board, (SELECT @rownum:=0) AS R
			WHERE
				BOARD_TYPE = 'C' ORDER BY RNUM DESC "
				.$search_condition;

	$result = mysqli_query($conn, $sql);

	$data = array();

	while($row = mysqli_fetch_array($result))
	{
		array_push( $data,
			array(
				'rnum'=>$row[0],
				'boardNo'=>$row[1],
				'title'=>$row[2],
				'writer'=>$row[4],
				'ymd'=>$row[7]
			));
	}

	$groupData = array();
	$groupData["rows"] = $data;
	$groupData["total"] = $total_pages;
	$groupData["records"] = $count;

	echo json_encode($groupData);


	mysqli_close($conn);

?>
