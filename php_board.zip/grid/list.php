﻿<?php include_once("../config.php"); ?>
<?php include_once("../db/db_connect.php"); ?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>게시판 리스트 페이지</title>

		<style>
			.button_area{width:750px; margin-bottom:5px; text-align:right;}
			.ui-jqgrid .ui-pg-input{height:18px !important;}
		</style>

		<script type="text/javascript">
			var msg = "";

			var dialog_obj =
			{
				resizable : false,
				autoOpen : true,
				title : "그리드 등록/수정",
				width : 700,
				height : 530,
				modal : true
			}
			
			function openGridForm(cmd, idx)
			{
				var grid_dialog = $("#grid_dialog").dialog(dialog_obj);

				grid_dialog.html("");
				grid_dialog.dialog("open");

				if(cmd == "insert")
				{
					url = "write.php";
					msg = "등록 창을 여는 중 문제가 발생했습니다";
					
				}
				else{
					url = "modified.php?boardNo="+idx;
					msg = "수정 창을 여는 중 문제가 발생했습니다";
				}

				$.ajax({
					url : "<?php $_SERVER['DOCUMENT_ROOT'] ?>/grid/"+url,
					type : "POST",
					beforeSend : function(jqXHR, settings){},
					success : function(data, status)
					{
						$("#grid_dialog").html(data);
					},
					error : function(data, error, status)
					{
						alert(msg);
						return false;
					}
				});
			}

			function reloadGrid()
			{
				$("#jqGrid").jqGrid().trigger("reloadGrid"); //Grid 새로고침
			}

			function closeGridForm()
			{
				$("#grid_dialog").dialog('close'); //등록창 닫기
			}


			$(function(){
				$("#jqGrid").jqGrid({
					url : "jsonGrid.php",
					datatype : 'json',
					width: 750,
					height: 250,
					mtype : "POST",
					colNames : ["번호", "게시판 번호", "제목", "작성자", "작성일"],
					colModel : [
						{label:"rnum", name:"rnum", index:"rnum", width:80, sortable:false, align:"center"},
						{label:"boardNo", name:"boardNo", index:"boardNo", key:true, sortable:false, align:"center", hidden:true},
						{label:"title", name:"title", index:"title", width:500, sortable:false, align:"left"},
						{label:"writer", name:"writer", index:"writer", width:100, sortable:false, align:"center"},
						{label:"ymd", name:"ymd", index:"ymd", width:100, sortable:false, align:"center"}
					],
					caption : "게시판 리스트",
					page : 1,
					rowList : [5, 10, 15, 20, 30, 50, 100],
					rowNum : 15,
					viewrecords : true,
					pager:"#jqGridPager",
					jsonReader : {
						root : "rows",
						repeatitems : false //colModel로 표현되는 모든 데이터의 순서가 일치 하지 않아도 됨..
					},
					loadComplete:function(data)
					{
						console.log(data);
					},
					loadError:function(xhr, status, error)
					{
						alert("데이터를 불러오는 중 실패 하였습니다."+error);
					},
					ondblClickRow : function(idx)
					{
						openGridForm('update',idx);
					}
				});
			});

		</script>
	</head>
	<body>
		<a href="<?php $web_path?>/index.php">홈으로</a> <br /><br />

		<div class="button_area">
			<button type="button" onclick="openGridForm('insert');">글 작성</button>
		</div>

		<div id="grid_dialog"></div>
		<table id="jqGrid"></table>
		<div id="jqGridPager"></div>
	</body>
</html>
