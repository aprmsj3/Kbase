﻿<?php include_once("../db/db_connect.php"); ?>

<?php
	$boardNo = $_POST["boardNo"];
	$title = addslashes($_POST["title"]);
	$content = addslashes($_POST["content"]);

	//그리드 수정 쿼리
	$grid_update_query =
		"UPDATE
			b01_board
		SET
			TITLE = '".$title."',
			CONTENT = '".$content."',
			MODIFIER = 'user',
			UPDT_DT = now()
		WHERE
			BOARD_NO ='".$boardNo."'";
	
	$update_result = mysqli_query($conn, $grid_update_query);

	if($update_result === false)
	{
			echo mysqli_error($conn)."<br />";
	}

	mysqli_close($conn);
?>