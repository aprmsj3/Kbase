﻿<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>파일 업로드 테스트 페이지</title>

		<style>
			
		</style>

		<script src='http://code.jquery.com/jquery.min.js'></script>
		<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery.form/3.51/jquery.form.min.js'></script>

		<script>
			$(function() {
				$('#uploadForm').ajaxForm({
					dataType: 'json',
					beforeSend: function() {
						$('#result').append( "beforeSend...\n" );
					},
					complete: function(data) {
						$('#result')
							.append( "complete...\n" )
							.append( JSON.stringify( data.responseJSON ) + "\n" );
					}
				});
			});
		</script>
	</head>
	<body>
		<a href="<?php $_SERVER['DOCUMENT_ROOT']?>/index.php">홈으로</a> <br />
		<h1>파일 업로드</h1>
		<form action="upload.php" id="uploadForm" name="uploadForm" enctype="multipart/form-data" method="POST">
			<input type="file" id="uploadFile" name="uploadFile" />
			<button type="submit">업로드</button>
		</form>
		<pre id="result">
		</pre>
	</body>
</html>