﻿<?php

	//업로드 경로
	$upload_dir = "./uploads";

	//확장자 지정
	$image_exe = array("jpg","jpeg","png","gif");

	//오류 체크
	if(!isset($_FILES['uploadFile']['error']))
	{
		echo json_encode( array(
			'status' => 'error',
			'message' => '파일이 첨부되지 않았습니다.'
		));
		exit;
	}

	$name = $_FILES['uploadFile']['name'];
	$ext = array_pop(explode('.', $name));

	move_uploaded_file($_FILES['uploadFile']['tmp_name'], "$upload_dir/$name");

	// 파일 정보 출력
	echo json_encode( array(
	'status' => 'OK',
	'name' => $name,
	'ext' => $ext,
	'type' => $_FILES['uploadFile']['type'],
	'size' => $_FILES['uploadFile']['size']
));

?>