﻿<?php include_once("/config.php"); ?>
<?php include_once("/db/db_connect.php"); ?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>게시판 리스트 페이지</title>

		<style>
			table{border:1px solid black; border-collapse:collapse; width:700px;}
			table th, td{margin:0; padding:0px;}
			table caption{text-align:left;}
			table th{text-align:center; border-top:1px solid black; border-bottom:1px solid black; background-color:#8892BF; padding:5px;}
			table td{text-align:left; background-color:#4F5B93; color:#E1E3EB;  padding:5px;}
			table td a{color:#E1E3EB; text-decoration:none;}
			.tCenter{text-align:center;}

			.button_area{width:700px; margin-bottom:5px; text-align:right;}
			.search_area{width:700px;}
			
			div#pagination_controls{font-size:21px; width:700px; text-align:center;}
			div#pagination_controls > a{ color:#06F; }
			div#pagination_controls > a:visited{ color:#06F; }
			div#pagination_info{width:700px; text-align:right;}

		</style>

		<script type="text/javascript">
			
			function hrefWritePage()
			{
				location.href = "<?php $web_path?>/write.php";
			}

			function hrefViewPage(boardNo)
			{
				$.ajax
				(
					{
						type : "POST",
						url : "<? $web_path?>/boardCnt_update.php",
						data : {"boardNo" : boardNo},
						success : function (data)
						{
							location.href = "<? $web_path?>/view.php?boardNo="+boardNo+"&pn=<?php echo $_GET['pn']?>";
						},
						error : function(xhr, status, error)
						{
							alert("조회 중 오류가 발생했습니다.\n");
						}
					}
				);
			}
		</script>
	</head>
	<body>
		<a href="<?php $web_path?>/index.php">홈으로</a> <br />

		<h1>게시판 리스트</h1>
		<div class="search_area">
			<form name="searchForm" method="POST">
				<input type="hidden" name="search" value="read" />
				<table>
					<tr>
						<th>검색</th>
						<td>
							<input type="text" class="full-width" id="searchVal" name="searchVal" value="<? echo $_POST['searchVal']?>" />
						</td>
						<td>
							<button type="submit">조회</button>
						</td>
					</tr>
				</table>
			</form>
		</div>
		
		<div class="button_area">
			<button type="button" onclick="hrefWritePage();">글 작성</button>
		</div>

		<table>
			<tr>
				<th>번호</th>
				<th>제목</th>
				<th>작성자</th>
				<th>작성일</th>
				<th>조회수</th>
			</tr>
<?php
	/* pageing 처리 */
	$read = "read";
	$search = $_POST['search'];
	$searchVal = $_POST['searchVal'];

	if($read === $search)
	{
		if("" !== $searchVal)
		{
			$search_condition = "TITLE LIKE"."'%".$searchVal."%'";
		}
	}
	
	// 1. 총 데이터의 수	
	$sql = "SELECT COUNT(0) FROM b01_board ".$search_condition;
	$query = mysqli_query($conn, $sql);
	$row = mysqli_fetch_row($query);

	$rows = $row[0];

	// 2. 한 페이지 당 리스트 수
	$page_rows = 10;

	// 마지막 페이지 번호 
	$last = ceil($rows/$page_rows); // * celi함수는 소수점은 무조건 반올림
	
	if($last < 1){
		$last = 1;
	}

	// 페이지 번호 setting 1로
	$pagenum = 1;

	if(isset($_GET['pn'])){
		$pagenum = preg_replace('#[^0-9]#', '', $_GET['pn']); // -> 0과 9를 제외한 문자열을 공백 처리한다.
	}

	if(1 > $pagenum){
		$pagenum = 1;
	}else if($pagenum > $last){
		$pagenum = $last;
	}

	$limit = 'LIMIT ' .($pagenum - 1) * $page_rows .',' .$page_rows;


	$search_condition = "1=1 ORDER BY BOARD_NO DESC $limit";

	
	if($read === $search)
	{
		if("" !== $searchVal)
		{
			$search_condition = "TITLE LIKE"."'%".$searchVal."%' $limit";
		}
	}

	//게시판 전체 조회
	$sql = "SELECT BOARD_NO, TITLE, CONTENT, WRITER, MODIFIER ,REGIST_DT, UPDT_DT, ifnull(BOARD_CNT, 0) as BOARD_CNT FROM b01_board	WHERE ".$search_condition;
	if(0 < $rows)
	{
		$paging_info = "Page <b>$pagenum</b> of <b>$last</b> / <b>$rows</b>";
	}else{
		$paging_info = "Page <b>$pagenum</b> of <b>$last</b> / <b>0</b>";
	}
	

	$result = mysqli_query($conn, $sql);

	$paginationCtrls = ''; //페이지번호 변수 선언

	if($last != 1)
	{
		if( $pagenum > 1) {
	    $previous = $pagenum - 1;
			$paginationCtrls .= '<a href="'.$_SERVER['PHP_SELF'].'?pn='.$previous.'">이전</a> &nbsp; &nbsp; ';

			for($i = $pagenum-4; $i < $pagenum; $i++){
				if($i > 0){
					$paginationCtrls .= '<a href="'.$_SERVER['PHP_SELF'].'?pn='.$i.'">'.$i.'</a> &nbsp; ';
				}
			}
		}

		$paginationCtrls .= ''.$pagenum.' &nbsp; ';

		for($i = $pagenum+1; $i <= $last; $i++){
			$paginationCtrls .= '<a href="'.$_SERVER['PHP_SELF'].'?pn='.$i.'">'.$i.'</a> &nbsp; ';
			if($i >= $pagenum+4){
				break;
			}
		}

		 if ($pagenum != $last) {
		  $next = $pagenum + 1;
		  $paginationCtrls .= ' &nbsp; <a href="'.$_SERVER['PHP_SELF'].'?pn='.$next.'">다음</a> ';
	   }
	}
	else if($last == 1)
	{
		$paginationCtrls .= ''.$pagenum.' &nbsp; ';
	}
			
	while($row = mysqli_fetch_array($result))
	{
?>
			<tr>
				<td class="tCenter"><? echo $row['BOARD_NO']?></td>
				<td>
					<a href="javascript:hrefViewPage('<? echo $row['BOARD_NO']?>')"><? echo $row['TITLE']?></a>
				</td>
				<td class="tCenter"><? echo $row['WRITER']?></td>
				<td class="tCenter"><? echo $row['REGIST_DT']?></td>
				<td class="tCenter"><? echo $row['BOARD_CNT']?></td>
			</tr>
		<?php 
			
		if(0 == $rows){ ?>
			<tr>
				<td colspan="4">검색결과가 없습니다.</td>
			</tr>
		<? } ?>
<? } ?>
		</table>
		<div id="pagination_info"><?php echo $paging_info; ?></div>
		<div id="pagination_controls"><?php echo $paginationCtrls; ?></div>

<?
	mysqli_close($conn);
?>
	</body>
</html>
