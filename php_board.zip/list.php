﻿<?php include_once("/config.php"); ?>
<?php include_once("/db/db_connect.php"); ?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>게시판 리스트 페이지</title>

		<style>
			table{border:1px solid black; border-collapse:collapse; width:600px;}
			table th, td{margin:0; padding:0px;}
			table caption{text-align:left;}
			table th{text-align:center; border-top:1px solid black; border-bottom:1px solid black; background-color:#8892BF; padding:5px;}
			table td{text-align:left; background-color:#4F5B93; color:#E1E3EB;  padding:5px;}
			table td a{color:#E1E3EB; text-decoration:none;}
			.tCenter{text-align:center;}

			.button_area{width:600px; margin-bottom:5px; text-align:right;}
		</style>

		<script type="text/javascript">
			
			function hrefWritePage()
			{
				location.href = "<?php $web_path?>/write.php";
			}

			function hrefViewPage(boardNo)
			{
				$.ajax
				(
					{
						type : "POST",
						url : "<? $web_path?>/boardCnt_update.php",
						data : {"boardNo" : boardNo},
						success : function (data)
						{
							location.href = "<? $web_path?>/view.php?boardNo="+boardNo;
						}
					}
				);
			}
		</script>
	</head>
	<body>
		<a href="<?php $web_path?>/index.php">홈으로</a> <br />

		<h1>게시판 리스트</h1>
		<div class="button_area">
			<button type="button" onclick="hrefWritePage();">글 작성</button>
		</div>

		<table>
			<tr>
				<th>번호</th>
				<th>제목</th>
				<th>작성자</th>
				<th>작성일</th>
				<th>조회수</th>
			</tr>
<?php

	//게시판 전체 조회
	$sql = "SELECT BOARD_NO, TITLE, CONTENT, WRITER, MODIFIER ,REGIST_DT, UPDT_DT, ifnull(BOARD_CNT, 0) as BOARD_CNT FROM b01_board;";
	$result = mysqli_query($conn, $sql);
			
	while($row = mysqli_fetch_array($result))
	{
?>
			<tr>
				<td class="tCenter"><? echo $row['BOARD_NO']?></td>
				<td>
					<a href="javascript:hrefViewPage('<? echo $row['BOARD_NO']?>')"><? echo $row['TITLE']?></a>
				</td>
				<td class="tCenter"><? echo $row['WRITER']?></td>
				<td class="tCenter"><? echo $row['REGIST_DT']?></td>
				<td class="tCenter"><? echo $row['BOARD_CNT']?></td>
			</tr>
<? }
	mysqli_close($conn);
?>
		</table>
	</body>
</html>
