﻿<?php include_once("/config.php"); ?>
<?php include_once("/db/db_connect.php"); ?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>게시판 리스트 페이지</title>

		<style>
			table{border:1px solid black; border-collapse:collapse; width:600px;}
			table th, td{margin:0; padding:0px;}
			table caption{text-align:left;}
			table th{text-align:center; border-top:1px solid black; border-bottom:1px solid black; background-color:#8892BF; padding:5px;}
			table td{text-align:left; background-color:#4F5B93; color:#E1E3EB;  padding:5px;}
			.tCenter{text-align:center;}

			.button_area{width:600px; margin-bottom:5px; text-align:right;}
		</style>

		<script type="text/javascript">
			
			function hrefWritePage()
			{
				location.href = "<?php $web_path?>/write.php";
			}
		</script>
	</head>
	<body>
		<a href="<?php $web_path?>/index.php">홈으로</a> <br />

		<h1>게시판 리스트</h1>
		<div class="button_area">
			<button type="button" onclick="hrefWritePage();">글 작성</button>
		</div>

		<table>
			<tr>
				<th>번호</th>
				<th>제목</th>
				<th>작성자</th>
				<th>작성일</th>
				<th>조회수</th>
			</tr>
<?php
	$sql = "SELECT * FROM B01_BOARD";
	$result = mysqli_query($conn, $sql);
			
	while($row = mysqli_fetch_array($result))
	{
		echo '<tr>';
		echo	'<td class="tCenter">'.$row['BOARD_NO'].'</td>';
		echo	'<td>'.$row['TITLE'].'</td>';
		echo	'<td class="tCenter">'.$row['WRITER'].'</td>';
		echo	'<td class="tCenter">'.$row['REGIST_DT'].'</td>';
		echo	'<td class="tCenter">0</td>';
		echo '</tr>';
	}
?>
		</table>
	</body>
</html>

