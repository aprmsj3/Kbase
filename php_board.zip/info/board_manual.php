﻿<?php include_once("../info/config.php"); ?>

<?php

	$page_settings = array
	(
		array('리스트 페이지', 'list.php'),
		array('작성 페이지', 'write.php'),
		array('등록', 'insert.php'),
	);
	
	//컬럼 값 배열 선언(컬럼, 컬럼명, 데이터유형, null여부, 제약조건)
	$board_column = array
	(
		array('BOARD_NO',	'게시판 고유번호', 'int(11)',		'NOT NULL', 'PK'),
		array('TITLE',		'게시판 제목',     'varchar(50)',	'NOT NULL', '-'),
		array('CONTENT',	'내용',            'text',			'NULL',		'-'),
		array('WRITER',		'작성자',          'varchar(20)',	'NOT NULL', '-'),
		array('MODIFIER',	'수정자',          'varchar(20)',	'NULL',		'-'),
		array('REGIST_DT',	'등록 날짜',       'date',			'NULL',		'-'),
		array('UPDT_DT',	'수정 날짜',       'date',			'NULL',		'-')
	);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>게시판 매뉴얼 및 정리</title>

		<style>
			table{border:1px solid black; border-collapse:collapse; width:600px;}
			table th, td{margin:0; padding:0px;}
			table caption{text-align:left;}
			table th{text-align:center; border:1px solid black; background-color:#8892BF; padding:10px;}
			table td{text-align:left; border:1px solid black; background-color:#4F5B93; color:#E1E3EB;  padding:5px;}
			.tCenter{text-align:center;}
		</style>
	</head>
	<body>
		<a href="<?php $web_path?>/index.php">홈으로</a> <br />

		<h1>페이지 구성</h1>
		<table>
			<colgroup>
				<col width="50%" />
				<col width="50%" />
			</colgroup>
			<tr>
				<th>파일이름</th>
				<th>파일 명</th>
			</tr>
<?php
	for($a=0; $a < count($page_settings); $a++){
?>
			<tr>
				<?php for($b=0; $b < count($page_settings[0]); $b++){ ?>

					<td><?php echo $page_settings[$a][$b] ?></td>
				<?php } ?>
			</tr>
<?php
	}
?>
		</table>

		<h1>게시판 테이블 설계</h1>
		<table>
			<caption>B01_BOARD(게시판 테이블)</caption>
			<tr>
				<th>컬럼</th>
				<th>컬럼명</th>
				<th>데이터유형</th>
				<th>NULL 여부</th>
				<th>제약조건</th>
			</tr>
<?php
	for($i=0; $i < count($board_column); $i++){
?>
			<tr>
				<?php for($j=0; $j < count($board_column[0]); $j++){ ?>

					<td class="<?php echo ($j >= 3) ? 'tCenter':'' ?>">
						<?php echo $board_column[$i][$j] ?>
					</td>
				<?php } ?>
			</tr>
<?php
	}
?>
		</table>
	</body>
</html>