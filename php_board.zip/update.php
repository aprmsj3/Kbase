﻿<?php include_once("/config.php"); ?>
<?php include_once("/db/db_connect.php"); ?>

<!--
	글 수정 시 ''가 들어가는 부분이 있는데 이부분 DB쿼리 실행시 에러가 발생 됨.
	무언가 bind를 해주는 prepeardstatement 가 필요??? 이스케이프를 치환해주는 게 필요 할 듯
	-> 해결 addslashes 함수로
-->


<?php

	//전송 시 POST방식으로 받기
	$boardNo = $_POST["boardNo"];
	$title = addslashes($_POST["title"]);
	$content = addslashes($_POST["content"]);
	
	//수정 쿼리
	$update_query = "UPDATE b01_board SET TITLE = '$title', CONTENT = '$content', MODIFIER = '$user', UPDT_DT = now() WHERE BOARD_NO ='".$boardNo."'";

	$update_result = mysqli_query($conn, $update_query);

	if($update_result === false)
	{
		echo mysqli_error($conn)."<br />";
	}else{
		echo "<script>
				alert(\"수정 되었습니다.\");
				location.href = \"$web_path/view.php?boardNo=$boardNo\";
			 </script>";
	}

	mysqli_close($conn);
?>