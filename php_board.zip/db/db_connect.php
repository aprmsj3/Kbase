﻿<?php

	header('Content-Type:text/html; charset=uft-8');

	$conn = mysqli_connect('localhost', 'root', 'autoset', 'board');


	if($conn->connect_errno)
	{
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
?>



