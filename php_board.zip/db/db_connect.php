﻿<?php

	header('Content-Type:text/html; charset=uft-8');

	$conn = mysqli_connect('localhost', 'root', 'autoset', 'board');

	if($conn->connect_errno)
	{
		echo "연결실패";
	}else{
		echo "연결성공";
	}
?>



