﻿<?php include_once("/config.php"); ?>
<?php include_once("/db/db_connect.php"); ?>

<?php
	$boardNo = $_POST["boardNo"];

	$sql = "UPDATE b01_board SET BOARD_CNT = ifnull(BOARD_CNT, 0)+1 WHERE BOARD_NO = '".$boardNo."'";

	if (mysqli_query($conn, $sql))
	{
	  echo "Record updated successfully";
	} else {
	  echo "Error updating record: " . mysqli_error($conn);
	}

	mysqli_close($conn);
?>