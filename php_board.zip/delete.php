﻿<?php include_once("/config.php"); ?>
<?php include_once("/db/db_connect.php"); ?>

<?php

	//전송 시 POST방식으로 받기
	$boardNo = $_POST["boardNo"];

	//삭제 쿼리
	$delete_query = "DELETE FROM b01_board WHERE BOARD_NO =".$boardNo;

	$result = mysqli_query($conn, $delete_query);

	if($result === false)
	{
		echo mysqli_error($conn)."<br />";
	}

	mysqli_close($conn);
?>