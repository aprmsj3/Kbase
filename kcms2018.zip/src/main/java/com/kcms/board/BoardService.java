package com.kcms.board;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kcms.util.Kmap;

public interface BoardService {

	public HashMap selectBoardList(Kmap kmap, HttpServletRequest request, HttpServletResponse response) throws Exception;
	public void boardCreate(Kmap kmap) throws Exception;
	public HashMap boardData(Kmap kmap) throws Exception;
	public void boardUpdate(Kmap kmap) throws Exception;
	public void boardDelete(Kmap kmap) throws Exception;

}
