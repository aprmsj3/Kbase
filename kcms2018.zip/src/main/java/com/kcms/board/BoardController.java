package com.kcms.board;

import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.kcms.util.Kmap;

@Controller
public class BoardController {
	
	@Resource
	private BoardService boardService;

	@RequestMapping(value= "/default_board/list.do", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView boardList(Kmap kmap, HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		ModelAndView mv = new ModelAndView("default_board/list");
		
		//model 객체를 DB에서 가져와야 한다.
		mv.addAllObjects(boardService.selectBoardList(kmap, request, response));

		return mv;
	}
	
	/* 게시판 등록 폼 */
	@RequestMapping(value="/default_board/writeForm.do", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView boardWriteView(HashMap map, HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		ModelAndView mv = new ModelAndView("default_board/write");
		
		return mv;
	}
	
	/* 게시판 등록  */
	@RequestMapping(value="/default_board/write.do", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView boardWrite(Kmap kmap, HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		ModelAndView mv = new ModelAndView("redirect:/default_board/list.do");
		boardService.boardCreate(kmap);
		
		return mv;
	}
	
	/* 게시판 상세보기  */
	@RequestMapping(value="/default_board/view.do", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView boardView(Kmap kmap, HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		ModelAndView mv = new ModelAndView("default_board/view");
		mv.addAllObjects(boardService.boardData(kmap));
		
		return mv;
	}
	
	/* 게시판 수정 폼  */
	@RequestMapping(value="/default_board/updateForm.do", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView boardUpdateView(Kmap kmap, HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		ModelAndView mv = new ModelAndView("default_board/update");
		mv.addAllObjects(boardService.boardData(kmap));
		
		return mv;
	}
	
	/* 게시판 수정  */
	@RequestMapping(value="/default_board/update.do", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView boardUpdate(Kmap kmap, HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		ModelAndView mv = new ModelAndView("redirect:/default_board/list.do");
		boardService.boardUpdate(kmap);
		
		return mv;
	}
	
	/* 게시판 삭제  */
	@RequestMapping(value="/default_board/boardDelete.do", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView boardDelete(Kmap kmap, HttpServletRequest request, HttpServletResponse response) throws Exception
	{
		ModelAndView mv = new ModelAndView("redirect:/default_board/list.do");
		boardService.boardDelete(kmap);
		
		return mv;
	}
}

