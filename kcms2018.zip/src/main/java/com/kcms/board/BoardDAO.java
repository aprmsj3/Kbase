package com.kcms.board;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Repository;

import com.kcms.common.SqlSessionDAO;
import com.kcms.util.Kmap;

@Repository
public class BoardDAO extends SqlSessionDAO {
	
	public List selectBoardList(Kmap kmap, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return (List) selectList("board.board_selectList_01");
	}

	public int selectBoardCount(Kmap kmap, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return count("board.board_count_01");
	}

	public void createBoard(HashMap boardMap) throws Exception{
		insert("board.insertBoard", boardMap);
	}

	public HashMap selectBoard(HashMap returnMap) throws Exception{
		return (HashMap) selectOne("board.selectBoard", returnMap);
	}

	public void updateBoard(HashMap boardMap) throws Exception {
		update("board.updateBoard", boardMap);
	}

	public void deleteBoard(HashMap boardMap) throws Exception {
		delete("board.deleteBoard", boardMap);
	}

}

