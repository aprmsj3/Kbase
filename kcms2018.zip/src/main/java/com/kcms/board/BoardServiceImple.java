package com.kcms.board;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

import com.kcms.util.CommonUtil;
import com.kcms.util.Kmap;

@Service
public class BoardServiceImple implements BoardService {
	
	@Resource(name="boardDAO")
	private BoardDAO boardDAO;

	@Override
	public HashMap selectBoardList(Kmap kmap, HttpServletRequest request, HttpServletResponse response) throws Exception 
	{
		HashMap returnMap = new HashMap();
		returnMap.put("list", boardDAO.selectBoardList(kmap, request, response)); //게시판 목록
		returnMap.put("count", boardDAO.selectBoardCount(kmap, request, response)); //게시판 카운트
		
		return returnMap;
	}

	@Override
	public void boardCreate(Kmap kmap) throws Exception
	{
		HashMap boardMap = new HashMap();
		boardMap.put("BOARD_NO", CommonUtil.createUuid());
		boardMap.put("BOARD_TITLE", kmap.getParameter("boardTitle"));
		boardMap.put("BOARD_CONTENT", kmap.getParameter("boardContent"));
		boardMap.put("REGISTER", "user");
		
		boardDAO.createBoard(boardMap);
	}

	@Override
	public HashMap boardData(Kmap kmap) throws Exception
	{
		HashMap paramMap = new HashMap();
		paramMap.put("BOARD_NO", kmap.getParameter("boardNo"));
		
		HashMap returnMap = new HashMap();
		returnMap.put("boardMap", boardDAO.selectBoard(paramMap));
		
		return returnMap;
	}

	@Override
	public void boardUpdate(Kmap kmap) throws Exception
	{
		HashMap boardMap = new HashMap();
		boardMap.put("BOARD_NO", kmap.getParameter("boardNo"));
		boardMap.put("BOARD_TITLE", kmap.getParameter("boardTitle"));
		boardMap.put("BOARD_CONTENT", kmap.getParameter("boardContent"));
		boardMap.put("REGISTER", "user");
		
		boardDAO.updateBoard(boardMap);
	}

	@Override
	public void boardDelete(Kmap kmap) throws Exception
	{
		HashMap boardMap = new HashMap();
		boardMap.put("BOARD_NO", kmap.getParameter("boardNo"));
		
		boardDAO.deleteBoard(boardMap);
	}

}
