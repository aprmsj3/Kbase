package com.kcms.first;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

	@RequestMapping(value= "/home.do", method = RequestMethod.GET)
	public ModelAndView Home()
	{
		ModelAndView mv = new ModelAndView();
		mv.addObject("mv", "Hello World!");

		System.out.println("HomeController 접속 됨...");

		return mv;
	}
}
