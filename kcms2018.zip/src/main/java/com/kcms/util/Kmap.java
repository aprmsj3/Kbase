package com.kcms.util;

import java.util.HashMap;
import java.util.Map;

public class Kmap {
	Map<String, Object> map = new HashMap<String, Object>();
	
	String value = "";
	
	public Object get(String key)
	{
		return map.get(key);
	}
	
	public String getParameter(String key)
	{
		if(null != map.get(key) || map.get(key).equals(""))
		{
			value = map.get(key).toString();
		}else{
			value = "";
		}
		
		return value;
	}
	
	public Object Allmap()
	{
		return map;
	}

	public void put(String key, Object value) {
		map.put(key, value);
	}
}
