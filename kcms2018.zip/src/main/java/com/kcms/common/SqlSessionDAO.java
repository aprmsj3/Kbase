package com.kcms.common;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

public class SqlSessionDAO {

	@Autowired
	private SqlSessionTemplate sqlSession;

	public Object insert(String queryId, Object params) {
		return sqlSession.insert(queryId, params);
	}

	public Object update(String queryId, Object params) {
		return sqlSession.update(queryId, params);
	}

	public Object delete(String queryId, Object params) {
		return sqlSession.delete(queryId, params);
	}

	public Object selectOne(String queryId) {
		return sqlSession.selectOne(queryId);
	}

	public Object selectOne(String queryId, Object params) {
		return sqlSession.selectOne(queryId, params);
	}
	
	public Object selectList(String queryId) {
		return sqlSession.selectList(queryId);
	}

	public Object selectList(String queryId, Object params) {
		return sqlSession.selectList(queryId, params);
	}
	
	public int count(String queryId) {
		return sqlSession.selectOne(queryId);
	}
	
	public int count(String queryId, Object params) {
		return sqlSession.selectOne(queryId, params);
	}

	
}
